#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == "--docker" ]]; then
  docker compose up
else
  (cd web && corepack enable && corepack prepare pnpm@9.10.0 --activate && pnpm install --frozen-lockfile --config.ignore-scripts=true && pnpm dev)
fi
