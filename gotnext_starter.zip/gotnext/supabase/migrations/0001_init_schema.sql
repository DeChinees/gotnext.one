-- GotNext Supabase schema + RLS

create extension if not exists pgcrypto;

do $$ begin
  create type role_kind as enum ('owner','admin','player');
exception when duplicate_object then null; end $$;

do $$ begin
  create type rsvp_status as enum ('going','maybe','out','waitlist');
exception when duplicate_object then null; end $$;

do $$ begin
  create type invite_channel as enum ('email','phone');
exception when duplicate_object then null; end $$;

create table if not exists app_user (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  email text,
  phone text,
  wa_jid text,
  created_at timestamptz not null default now()
);
create index if not exists app_user_email_idx on app_user (email);
create index if not exists app_user_phone_idx on app_user (phone);

create table if not exists team (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  is_private boolean not null default true,
  created_by uuid not null references app_user(user_id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists team_member (
  team_id uuid not null references team(id) on delete cascade,
  user_id uuid not null references app_user(user_id) on delete cascade,
  role role_kind not null default 'player',
  joined_at timestamptz not null default now(),
  primary key (team_id, user_id)
);
create index if not exists team_member_user_idx on team_member (user_id);
create index if not exists team_member_role_idx on team_member (team_id, role);

create table if not exists event (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references team(id) on delete cascade,
  title text not null,
  starts_at timestamptz not null,
  ends_at timestamptz,
  location text,
  notes text,
  capacity int not null check (capacity > 0),
  rsvp_deadline timestamptz,
  recurrence_rule text,
  is_locked boolean not null default false,
  created_by uuid not null references app_user(user_id) on delete restrict,
  created_at timestamptz not null default now()
);
create index if not exists event_team_time_idx on event (team_id, starts_at);
create index if not exists event_deadline_idx on event (rsvp_deadline);

create table if not exists rsvp (
  event_id uuid not null references event(id) on delete cascade,
  user_id uuid not null references app_user(user_id) on delete cascade,
  status rsvp_status not null,
  waitlist_position int,
  updated_at timestamptz not null default now(),
  primary key (event_id, user_id),
  constraint rsvp_waitlist_pos_ck check (
    (status = 'waitlist' and waitlist_position is not null)
    or (status <> 'waitlist' and waitlist_position is null)
  )
);
create index if not exists rsvp_event_status_idx on rsvp (event_id, status);
create index if not exists rsvp_waitlist_order_idx on rsvp (event_id, waitlist_position);

create table if not exists invite (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references team(id) on delete cascade,
  token text not null unique,
  channel invite_channel not null,
  delivered_to text not null,
  invited_by uuid not null references app_user(user_id) on delete restrict,
  expires_at timestamptz,
  accepted_by uuid references app_user(user_id) on delete set null,
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists invite_team_idx on invite (team_id);
create index if not exists invite_token_idx on invite (token);

create or replace function next_waitlist_position(p_event uuid)
returns int language sql stable as $$
  select coalesce(max(waitlist_position), 0) + 1
  from rsvp
  where event_id = p_event and status = 'waitlist'
$$;

create or replace view event_counts as
select
  e.id as event_id,
  count(*) filter (where r.status = 'going')    as going_count,
  count(*) filter (where r.status = 'maybe')    as maybe_count,
  count(*) filter (where r.status = 'out')      as out_count,
  count(*) filter (where r.status = 'waitlist') as waitlist_count
from event e
left join rsvp r on r.event_id = e.id
group by e.id;

-- Enable RLS
alter table app_user    enable row level security;
alter table team        enable row level security;
alter table team_member enable row level security;
alter table event       enable row level security;
alter table rsvp        enable row level security;
alter table invite      enable row level security;

-- APP_USER policies
create policy if not exists "read own profile"
  on app_user for select
  using (user_id = auth.uid());

create policy if not exists "update own profile"
  on app_user for update
  using (user_id = auth.uid());

-- TEAM policies
create policy if not exists "select teams as member"
  on team for select
  using (exists (
    select 1 from team_member tm
    where tm.team_id = team.id and tm.user_id = auth.uid()
  ));

create policy if not exists "insert teams (any authenticated)"
  on team for insert
  with check (auth.role() = 'authenticated');

create policy if not exists "manage team as admin"
  on team for update
  using (exists (
    select 1 from team_member tm
    where tm.team_id = team.id and tm.user_id = auth.uid()
      and tm.role in ('owner','admin')
  ));

create policy if not exists "delete team as owner"
  on team for delete
  using (exists (
    select 1 from team_member tm
    where tm.team_id = team.id and tm.user_id = auth.uid()
      and tm.role = 'owner'
  ));

-- TEAM_MEMBER policies
create policy if not exists "select memberships in my teams"
  on team_member for select
  using (exists (
    select 1 from team_member me
    where me.team_id = team_member.team_id and me.user_id = auth.uid()
  ));

create policy if not exists "insert membership as admin"
  on team_member for insert
  with check (exists (
    select 1 from team_member me
    where me.team_id = team_member.team_id and me.user_id = auth.uid()
      and me.role in ('owner','admin')
  ));

create policy if not exists "update membership as admin"
  on team_member for update
  using (exists (
    select 1 from team_member me
    where me.team_id = team_member.team_id and me.user_id = auth.uid()
      and me.role in ('owner','admin')
  ));

create policy if not exists "delete self membership"
  on team_member for delete
  using (user_id = auth.uid());

-- EVENT policies
create policy if not exists "select events as member"
  on event for select
  using (exists (
    select 1 from team_member tm
    where tm.team_id = event.team_id and tm.user_id = auth.uid()
  ));

create policy if not exists "insert event as admin"
  on event for insert
  with check (exists (
    select 1 from team_member tm
    where tm.team_id = event.team_id and tm.user_id = auth.uid()
      and tm.role in ('owner','admin')
  ));

create policy if not exists "update event as admin"
  on event for update
  using (exists (
    select 1 from team_member tm
    where tm.team_id = event.team_id and tm.user_id = auth.uid()
      and tm.role in ('owner','admin')
  ));

create policy if not exists "delete event as admin"
  on event for delete
  using (exists (
    select 1 from team_member tm
    where tm.team_id = event.team_id and tm.user_id = auth.uid()
      and tm.role in ('owner','admin')
  ));

-- RSVP policies
create policy if not exists "select rsvp as member"
  on rsvp for select
  using (exists (
    select 1 from team_member tm
    join event e on e.id = rsvp.event_id
    where tm.team_id = e.team_id and tm.user_id = auth.uid()
  ));

create policy if not exists "upsert own rsvp"
  on rsvp for insert
  with check (
    user_id = auth.uid() and
    exists (
      select 1 from event e
      join team_member tm on tm.team_id = e.team_id
      where e.id = rsvp.event_id and tm.user_id = auth.uid()
    )
  );

create policy if not exists "update own rsvp"
  on rsvp for update
  using (user_id = auth.uid());

create policy if not exists "admin insert rsvp"
  on rsvp for insert
  with check (exists (
    select 1 from team_member tm
    join event e on e.id = rsvp.event_id
    where tm.team_id = e.team_id and tm.user_id = auth.uid()
      and tm.role in ('owner','admin')
  ));

create policy if not exists "admin update rsvp"
  on rsvp for update
  using (exists (
    select 1 from team_member tm
    join event e on e.id = rsvp.event_id
    where e.id = rsvp.event_id and tm.user_id = auth.uid()
      and tm.role in ('owner','admin')
  ));
